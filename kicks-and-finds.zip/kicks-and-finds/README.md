# 👟 Kicks & Finds

Pre-loved footwear & bags storefront for Mombasa, Kenya.
**Google Sheets backend · React frontend · WhatsApp checkout · GitHub Pages / Netlify hosting.**

---

## Features

- 📦 **Live Google Sheets backend** — edit your sheet and the site updates automatically
- 🔍 Search, category filter, show/hide sold items
- 💬 WhatsApp enquiry & Lipa Pole Pole buttons per listing
- 🔐 PIN-protected admin mode (edit prices & toggle sold/available)
- 📱 Fully responsive
- ⚡ Zero monthly cost (GitHub Pages + Google Sheets are free)

---

## Quick start (local dev)

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/kicks-and-finds.git
cd kicks-and-finds

# 2. Install dependencies
npm install

# 3. Set your admin PIN
cp .env.example .env
#    Open .env and change VITE_ADMIN_PIN=1234 to something secret

# 4. Run dev server
npm run dev
#    Open http://localhost:5173
```

---

## Connecting Google Sheets (the backend)

### Step 1 — Create the spreadsheet

1. Open [Google Sheets](https://sheets.google.com) and create a new spreadsheet.
2. Rename the first sheet tab to **Products** (exact spelling).
3. Add this header row in **Row 1**:

| A | B | C | D | E | F | G | H | I | J | K | L | M | N |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| id | name | brand | price | category | condition | available | postedAt | whatsapp | description | image1 | image2 | image3 | image4 |

4. Fill in your products starting from Row 2. Examples:

```
id        → 1
name      → Nike Air Force 1 Triple Black
brand     → Nike
price     → 6500
category  → Sneakers
condition → Used – Very Good
available → TRUE
postedAt  → 2026-04-16T07:30:00
whatsapp  → 254700000000
description → All-black Nike AF1 Low. Minor creasing on toe box.
image1    → https://your-image-url.com/photo1.jpg
image2    → (leave blank if only one photo)
```

> **Images:** Upload your photos to [ImgBB](https://imgbb.com), Google Drive (with public share link), or any image host and paste the direct URL.

---

### Step 2 — Deploy the Apps Script

1. In your Google Sheet, click **Extensions → Apps Script**.
2. Delete the default code and paste the **entire contents** of `scripts/google-apps-script.js`.
3. Click **Save** (Ctrl+S).
4. Click **Deploy → New deployment**.
5. Set:
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
6. Click **Deploy** → **Authorize** → copy the **Web App URL**.

---

### Step 3 — Connect the URL to the site

Open `src/hooks/useSheets.js` and replace:

```js
WEB_APP_URL: "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec",
```

with the URL you copied. Save the file.

---

## Deploying to GitHub Pages

```bash
# 1. Build the site
npm run build

# 2. If hosting at https://username.github.io/kicks-and-finds/
#    open vite.config.js and set:
#    base: "/kicks-and-finds/"
#    then rebuild: npm run build

# 3. Push to GitHub
git add .
git commit -m "Initial deploy"
git push origin main

# 4. In your GitHub repo:
#    Settings → Pages → Source: GitHub Actions
#    OR use the gh-pages package:
npm install --save-dev gh-pages
#    Add to package.json scripts:
#    "deploy": "gh-pages -d dist"
npm run build && npm run deploy
```

---

## Deploying to Netlify (easier, recommended)

1. Push the repo to GitHub.
2. Go to [netlify.com](https://netlify.com) → **Add new site → Import from Git**.
3. Set build command: `npm run build`  |  Publish directory: `dist`
4. In **Site settings → Environment variables**, add `VITE_ADMIN_PIN=your_pin`.
5. Click **Deploy**. Done — auto-deploys on every `git push`.

---

## Managing listings (no-code)

After setup, **you never need to touch code again**. Just:

| Action | How |
|--------|-----|
| Add a new listing | Add a row to the Google Sheet |
| Change a price | Edit column D in the sheet **or** use Admin mode on the site |
| Mark as sold | Set column G to `FALSE` in the sheet **or** use Admin mode |
| Add/change photos | Update image1–4 columns with new URLs |

Changes appear on the site within seconds (page refresh).

---

## Admin mode

Click **Admin** in the top-right header → enter your PIN.  
In admin mode you can:
- ✏️ Edit prices directly on each card (syncs to the sheet)
- 🔄 Toggle Available / Sold on any listing (syncs to the sheet)

---

## Project structure

```
kicks-and-finds/
├── public/
│   └── logo.jpg                  ← your logo (already included)
├── scripts/
│   └── google-apps-script.js     ← paste into Google Apps Script
├── src/
│   ├── components/
│   │   ├── ProductCard.jsx
│   │   ├── ProductImage.jsx
│   │   └── PriceEditor.jsx
│   ├── hooks/
│   │   └── useSheets.js          ← ← paste your Web App URL here
│   ├── utils/
│   │   └── helpers.js
│   ├── App.jsx
│   └── main.jsx
├── .env.example                  ← copy to .env, set your PIN
├── index.html
├── package.json
└── vite.config.js
```

---

## Customising WhatsApp number

In the Google Sheet, column I (`whatsapp`) — enter your number with country code, **no spaces or +**, e.g. `254712345678`.

---

*Built with React + Vite. Backend powered by Google Sheets + Apps Script. Free to host forever.*
