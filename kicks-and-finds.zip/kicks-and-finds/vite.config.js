import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // If deploying to GitHub Pages at https://username.github.io/kicks-and-finds/
  // set base to your repo name:
  // base: "/kicks-and-finds/",
  base: "/",
});
