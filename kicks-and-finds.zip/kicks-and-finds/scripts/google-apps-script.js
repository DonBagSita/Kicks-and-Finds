/**
 * ═══════════════════════════════════════════════════════════════════
 *  KICKS & FINDS — Google Apps Script Backend
 *  Paste this entire file into Google Apps Script, then:
 *  Deploy → New deployment → Web App → Anyone → Deploy
 *  Copy the Web App URL into src/hooks/useSheets.js
 * ═══════════════════════════════════════════════════════════════════
 *
 *  SHEET STRUCTURE (Sheet name: "Products")
 *  Row 1 is the header row. Columns:
 *  A: id        (number)
 *  B: name      (text)
 *  C: brand     (text)
 *  D: price     (number)
 *  E: category  (text, e.g. Sneakers / Loafers / Clogs / Bags)
 *  F: condition (text, e.g. "Used – Good")
 *  G: available (TRUE or FALSE)
 *  H: postedAt  (ISO datetime, e.g. 2026-04-16T08:00:00)
 *  I: whatsapp  (number with country code, e.g. 254700000000)
 *  J: description (text)
 *  K: image1    (full https:// URL)
 *  L: image2    (full https:// URL, optional)
 *  M: image3    (full https:// URL, optional)
 *  N: image4    (full https:// URL, optional)
 */

const SHEET_NAME = "Products";

// ─── GET handler ────────────────────────────────────────────────────────────
function doGet(e) {
  const action = e && e.parameter && e.parameter.action;

  if (action === "getProducts" || !action) {
    return jsonResponse(getProducts());
  }

  return jsonResponse({ error: "Unknown action" });
}

// ─── POST handler ────────────────────────────────────────────────────────────
function doPost(e) {
  let body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch {
    return jsonResponse({ error: "Invalid JSON" });
  }

  switch (body.action) {
    case "updatePrice":
      return jsonResponse(updatePrice(body.id, body.price));
    case "toggleAvailable":
      return jsonResponse(toggleAvailable(body.id, body.available));
    default:
      return jsonResponse({ error: "Unknown action" });
  }
}

// ─── Read all products ───────────────────────────────────────────────────────
function getProducts() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return { error: `Sheet "${SHEET_NAME}" not found` };

  const rows = sheet.getDataRange().getValues();
  if (rows.length < 2) return { products: [] };

  // Skip header row (index 0)
  const products = rows.slice(1).map((row) => {
    const images = [row[10], row[11], row[12], row[13]]
      .map(String)
      .filter((u) => u.startsWith("http"));

    return {
      id:          Number(row[0]),
      name:        String(row[1]),
      brand:       String(row[2]),
      price:       Number(row[3]),
      category:    String(row[4]),
      condition:   String(row[5]),
      available:   row[6] === true || String(row[6]).toLowerCase() === "true",
      postedAt:    String(row[7]),
      whatsapp:    String(row[8]),
      description: String(row[9]),
      images,
    };
  });

  return { products };
}

// ─── Update a product's price ────────────────────────────────────────────────
function updatePrice(id, price) {
  const result = findRow(id);
  if (!result) return { error: "Product not found" };
  result.sheet.getRange(result.rowIndex, 4).setValue(price); // column D
  return { ok: true };
}

// ─── Toggle available flag ───────────────────────────────────────────────────
function toggleAvailable(id, available) {
  const result = findRow(id);
  if (!result) return { error: "Product not found" };
  result.sheet.getRange(result.rowIndex, 7).setValue(available); // column G
  return { ok: true };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function findRow(id) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return null;

  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (Number(data[i][0]) === Number(id)) {
      return { sheet, rowIndex: i + 1 }; // 1-based
    }
  }
  return null;
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
