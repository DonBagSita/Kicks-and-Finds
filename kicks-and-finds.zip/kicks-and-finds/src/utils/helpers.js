export function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr)) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export function formatPrice(p) {
  return `KES ${Number(p).toLocaleString()}`;
}

export function buildWhatsAppLink(whatsapp, productName, price, mode = "enquire") {
  const msg =
    mode === "lipa"
      ? `Hi! I'd like to book the *${productName}* (${formatPrice(price)}) on Lipa Pole Pole. What's the deposit amount? 🙏`
      : `Hi! I'm interested in the *${productName}* listed at *${formatPrice(price)}*. Is it still available? 👟`;
  return `https://wa.me/${whatsapp}?text=${encodeURIComponent(msg)}`;
}
