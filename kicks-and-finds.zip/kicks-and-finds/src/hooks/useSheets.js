import { useState, useEffect, useCallback } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURATION — replace with your own values
// ─────────────────────────────────────────────────────────────────────────────
// 1. Deploy the Google Apps Script (see scripts/google-apps-script.js) as a
//    Web App and paste the URL here.
// 2. Set your Google Sheet ID below (found in the sheet URL).
export const SHEETS_CONFIG = {
  // Your deployed Apps Script Web App URL:
  WEB_APP_URL: "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec",
  // The spreadsheet ID from the URL:
  SHEET_ID: "YOUR_SHEET_ID",
};

// ─────────────────────────────────────────────────────────────────────────────
// Fallback local data used when the sheet is not yet configured
// ─────────────────────────────────────────────────────────────────────────────
const FALLBACK_PRODUCTS = [
  {
    id: 1,
    name: "Birkenstock Amsterdam Wool Clogs",
    brand: "Birkenstock",
    price: 4500,
    category: "Clogs",
    condition: "Used – Good",
    available: true,
    postedAt: "2026-04-16T08:00:00",
    images: [
      "https://images.unsplash.com/photo-1603487742131-4160ec999306?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "Dark grey wool felt Birkenstock Amsterdam clogs. Cork footbed with natural leather lining. Loved but still have life in them.",
  },
  {
    id: 2,
    name: "Nike Air Force 1 Triple Black",
    brand: "Nike",
    price: 6500,
    category: "Sneakers",
    condition: "Used – Very Good",
    available: true,
    postedAt: "2026-04-16T07:30:00",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "All-black Nike Air Force 1 Low. Clean leather upper with shoe trees included. Minor creasing on toe box.",
  },
  {
    id: 3,
    name: "Nike Court Legacy White Canvas",
    brand: "Nike",
    price: 5800,
    category: "Sneakers",
    condition: "Used – Good",
    available: true,
    postedAt: "2026-04-15T19:00:00",
    images: [
      "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "White canvas Nike Court Legacy. Retro low-profile silhouette. Some canvas yellowing — adds character.",
  },
  {
    id: 4,
    name: "Black Patent Penny Loafers",
    brand: "Unbranded",
    price: 3200,
    category: "Loafers",
    condition: "Used – Good",
    available: false,
    postedAt: "2026-04-15T14:00:00",
    images: [
      "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "High-shine black patent leather penny loafers. Classic silhouette with moccasin stitching.",
  },
  {
    id: 5,
    name: "Chunky Horsebit Loafers",
    brand: "Unbranded",
    price: 7500,
    category: "Loafers",
    condition: "Used – Excellent",
    available: true,
    postedAt: "2026-04-15T12:00:00",
    images: [
      "https://images.unsplash.com/photo-1617713964959-d9a36bbc7b52?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "Black leather chunky lug-sole loafers with gold horsebit hardware. Very lightly worn. Perfect statement shoe.",
  },
  {
    id: 6,
    name: "Adidas Sabalo Red Suede",
    brand: "Adidas",
    price: 5500,
    category: "Sneakers",
    condition: "Used – Good",
    available: true,
    postedAt: "2026-04-15T10:00:00",
    images: [
      "https://images.unsplash.com/photo-1578116922645-3976907a7671?w=600&q=80",
    ],
    whatsapp: "254700000000",
    description:
      "Burnt red suede Adidas Sabalo with clean white cupsole. A rare colourway — seriously a head-turner.",
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// Hook
// ─────────────────────────────────────────────────────────────────────────────
export function useSheets() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [usingFallback, setUsingFallback] = useState(false);

  const isConfigured =
    SHEETS_CONFIG.WEB_APP_URL &&
    !SHEETS_CONFIG.WEB_APP_URL.includes("YOUR_SCRIPT_ID");

  const fetchProducts = useCallback(async () => {
    if (!isConfigured) {
      setProducts(FALLBACK_PRODUCTS);
      setUsingFallback(true);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const res = await fetch(`${SHEETS_CONFIG.WEB_APP_URL}?action=getProducts`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setProducts(data.products || []);
      setUsingFallback(false);
    } catch (err) {
      console.warn("Sheet fetch failed, using fallback data:", err.message);
      setProducts(FALLBACK_PRODUCTS);
      setUsingFallback(true);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [isConfigured]);

  // Update a single product's price in the sheet
  const updatePrice = useCallback(
    async (id, newPrice) => {
      // Optimistically update local state
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, price: newPrice } : p))
      );

      if (!isConfigured) return; // nothing to sync in fallback mode

      try {
        await fetch(SHEETS_CONFIG.WEB_APP_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "updatePrice", id, price: newPrice }),
        });
      } catch (err) {
        console.error("Price sync failed:", err.message);
      }
    },
    [isConfigured]
  );

  // Toggle available/sold in the sheet
  const toggleAvailable = useCallback(
    async (id, available) => {
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, available } : p))
      );

      if (!isConfigured) return;

      try {
        await fetch(SHEETS_CONFIG.WEB_APP_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "toggleAvailable", id, available }),
        });
      } catch (err) {
        console.error("Availability sync failed:", err.message);
      }
    },
    [isConfigured]
  );

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  return { products, loading, error, usingFallback, updatePrice, toggleAvailable, refetch: fetchProducts };
}
