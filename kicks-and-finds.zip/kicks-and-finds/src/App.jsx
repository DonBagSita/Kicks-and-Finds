import { useState } from "react";
import { Search } from "lucide-react";
import ProductCard from "./components/ProductCard";
import { useSheets } from "./hooks/useSheets";
import logo from "/logo.jpg";

const PIN = import.meta.env.VITE_ADMIN_PIN || "1234"; // Set VITE_ADMIN_PIN in .env

export default function App() {
  const { products, loading, usingFallback, updatePrice, toggleAvailable } = useSheets();

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [showSold, setShowSold] = useState(true);

  // Admin
  const [adminMode, setAdminMode] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [adminPin, setAdminPin] = useState("");
  const [pinError, setPinError] = useState(false);

  const categories = ["All", ...Array.from(new Set(products.map((p) => p.category)))];

  const filtered = [...products]
    .sort((a, b) => new Date(b.postedAt) - new Date(a.postedAt))
    .filter((p) => {
      if (!showSold && !p.available) return false;
      const matchSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.brand.toLowerCase().includes(search.toLowerCase());
      const matchCat = filter === "All" || p.category === filter;
      return matchSearch && matchCat;
    });

  function handleAdminToggle() {
    if (adminMode) { setAdminMode(false); return; }
    setShowPinModal(true);
  }

  function handlePinSubmit() {
    if (adminPin === PIN) {
      setAdminMode(true);
      setShowPinModal(false);
      setAdminPin("");
      setPinError(false);
    } else {
      setPinError(true);
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f7f4f0", fontFamily: "'DM Sans', sans-serif" }}>

      {/* ─── HEADER ──────────────────────────────────────────────────────────── */}
      <header style={{
        background: "#1a1a1a", color: "#fff",
        position: "sticky", top: 0, zIndex: 100,
        boxShadow: "0 2px 16px rgba(0,0,0,0.25)",
      }}>
        <div style={{
          maxWidth: 1100, margin: "0 auto", padding: "0 20px",
          display: "flex", alignItems: "center", justifyContent: "space-between", height: 68,
        }}>
          {/* Logo + wordmark */}
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <img
              src={logo}
              alt="Kicks & Finds logo"
              style={{ height: 48, width: 48, borderRadius: "50%", objectFit: "cover", border: "2px solid #c8a96e" }}
            />
            <div>
              <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
                Kicks <span style={{ color: "#c8a96e" }}>&amp;</span> Finds
              </span>
              <div style={{ fontSize: 10, color: "#888", letterSpacing: "0.14em", textTransform: "uppercase", marginTop: -1 }}>
                Pre-loved · Mombasa
              </div>
            </div>
          </div>

          {/* Right controls */}
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <span style={{ fontSize: 12, color: "#888" }}>{filtered.length} items</span>
            <button
              onClick={handleAdminToggle}
              style={{
                background: adminMode ? "#c8a96e" : "transparent",
                color: adminMode ? "#1a1a1a" : "#888",
                border: "1px solid", borderColor: adminMode ? "#c8a96e" : "#444",
                borderRadius: 8, padding: "6px 14px", cursor: "pointer",
                fontSize: 12, fontWeight: 600, fontFamily: "'DM Sans', sans-serif",
                transition: "all 0.2s",
              }}
            >
              {adminMode ? "✏️ Editing" : "Admin"}
            </button>
          </div>
        </div>
      </header>

      {/* ─── HERO STRIP ──────────────────────────────────────────────────────── */}
      <div style={{ background: "linear-gradient(135deg, #1a1a1a 0%, #2d2420 100%)", padding: "22px 20px", textAlign: "center" }}>
        <p style={{ margin: 0, color: "#c8a96e", fontFamily: "'DM Sans', sans-serif", fontSize: 13, letterSpacing: "0.2em", textTransform: "uppercase" }}>
          ✦ Fresh drops · Lipa Pole Pole available · DM to cop ✦
        </p>
      </div>

      {/* ─── FALLBACK NOTICE ─────────────────────────────────────────────────── */}
      {usingFallback && (
        <div style={{
          background: "#fff8ec", borderBottom: "1px solid #f0ddb0",
          padding: "10px 20px", textAlign: "center",
          fontSize: 12, color: "#9a6f28", fontFamily: "'DM Sans', sans-serif",
        }}>
          📋 Showing demo data. Connect Google Sheets to load live listings — see <strong>README.md</strong>.
        </div>
      )}

      {/* ─── SEARCH + FILTERS ────────────────────────────────────────────────── */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 20px 0" }}>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>

          {/* Search */}
          <div style={{ flex: 1, minWidth: 220, position: "relative" }}>
            <Search size={15} style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "#aaa" }} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search shoes, bags…"
              style={{
                width: "100%", padding: "12px 14px 12px 38px",
                border: "1.5px solid #e8e4df", borderRadius: 12,
                fontFamily: "'DM Sans', sans-serif", fontSize: 14,
                background: "#fff", outline: "none",
                transition: "border-color 0.2s",
              }}
              onFocus={(e) => (e.target.style.borderColor = "#c8a96e")}
              onBlur={(e) => (e.target.style.borderColor = "#e8e4df")}
            />
          </div>

          {/* Category pills */}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                style={{
                  padding: "9px 18px", borderRadius: 20,
                  border: filter === cat ? "2px solid #c8a96e" : "1.5px solid #e0dbd4",
                  background: filter === cat ? "#c8a96e" : "#fff",
                  color: filter === cat ? "#1a1a1a" : "#666",
                  fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 13,
                  cursor: "pointer", transition: "all 0.18s",
                }}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Show sold toggle */}
          <button
            onClick={() => setShowSold((v) => !v)}
            style={{
              padding: "9px 14px", borderRadius: 20,
              border: "1.5px solid #e0dbd4",
              background: showSold ? "#1a1a1a" : "#fff",
              color: showSold ? "#c8a96e" : "#999",
              fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 12,
              cursor: "pointer", transition: "all 0.18s", whiteSpace: "nowrap",
            }}
          >
            {showSold ? "✓ Showing sold" : "Show sold"}
          </button>
        </div>

        {adminMode && (
          <div style={{
            marginTop: 14, background: "#fff8ec",
            border: "1.5px dashed #c8a96e", borderRadius: 10,
            padding: "10px 16px", fontSize: 13, color: "#9a6f28", fontWeight: 600,
          }}>
            ✏️ Admin mode — edit prices with the pencil icon, or toggle sold/available on each card.
          </div>
        )}
      </div>

      {/* ─── GRID ────────────────────────────────────────────────────────────── */}
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 20px 60px" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: "80px 0", color: "#c8a96e", fontFamily: "'Playfair Display', serif", fontSize: 22 }}>
            Loading listings…
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 0", color: "#aaa", fontFamily: "'Playfair Display', serif", fontSize: 22 }}>
            No items found 👟
          </div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
            gap: 24,
          }}>
            {filtered.map((product, i) => (
              <div
                key={product.id}
                style={{ animation: `fadeUp 0.45s ease ${i * 0.06}s both` }}
              >
                <ProductCard
                  product={product}
                  onUpdatePrice={updatePrice}
                  onToggleAvailable={toggleAvailable}
                  adminMode={adminMode}
                />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ─── FOOTER ──────────────────────────────────────────────────────────── */}
      <footer style={{ background: "#1a1a1a", padding: "40px 20px", textAlign: "center" }}>
        <img
          src={logo}
          alt="Kicks & Finds"
          style={{ height: 64, width: 64, borderRadius: "50%", objectFit: "cover", marginBottom: 16, border: "2px solid #c8a96e" }}
        />
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#c8a96e", marginBottom: 6 }}>
          Kicks <span style={{ color: "#fff" }}>&amp;</span> Finds
        </div>
        <p style={{ color: "#666", fontSize: 12, fontFamily: "'DM Sans', sans-serif", margin: 0 }}>
          Pre-loved footwear &amp; bags · Mombasa, Kenya · DM to cop 👟
        </p>
      </footer>

      {/* ─── ADMIN PIN MODAL ─────────────────────────────────────────────────── */}
      {showPinModal && (
        <div
          style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)",
            zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center",
          }}
          onClick={() => { setShowPinModal(false); setAdminPin(""); setPinError(false); }}
        >
          <div
            style={{
              background: "#fff", borderRadius: 18, padding: "36px 32px",
              boxShadow: "0 20px 60px rgba(0,0,0,0.25)", minWidth: 300,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#1a1a1a", margin: "0 0 6px" }}>Admin Access</h3>
            <p style={{ color: "#888", fontSize: 13, fontFamily: "'DM Sans', sans-serif", margin: "0 0 20px" }}>
              Enter PIN to edit listings
            </p>
            <input
              type="password"
              value={adminPin}
              onChange={(e) => { setAdminPin(e.target.value); setPinError(false); }}
              onKeyDown={(e) => e.key === "Enter" && handlePinSubmit()}
              placeholder="••••"
              style={{
                width: "100%", padding: "12px 16px",
                border: `2px solid ${pinError ? "#e74c3c" : "#e0dbd4"}`,
                borderRadius: 10, fontSize: 20, letterSpacing: "0.3em",
                textAlign: "center", fontFamily: "monospace", outline: "none", marginBottom: 8,
              }}
            />
            {pinError && (
              <p style={{ color: "#e74c3c", fontSize: 12, margin: "0 0 12px", fontFamily: "'DM Sans', sans-serif" }}>
                Wrong PIN. Try again.
              </p>
            )}
            <button
              onClick={handlePinSubmit}
              style={{
                width: "100%", background: "#1a1a1a", color: "#c8a96e",
                border: "none", borderRadius: 10, padding: "13px",
                fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: 15, cursor: "pointer",
                marginTop: 4,
              }}
            >
              Unlock
            </button>
          </div>
        </div>
      )}

      {/* Keyframes */}
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
