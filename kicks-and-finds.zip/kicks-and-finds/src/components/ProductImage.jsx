import { useState } from "react";

export default function ProductImage({ images = [], available, name }) {
  const [idx, setIdx] = useState(0);
  const src = images[idx] || "";

  return (
    <div style={{ position: "relative", width: "100%", paddingBottom: "125%", background: "#f0ede8", overflow: "hidden" }}>
      {src ? (
        <img
          src={src}
          alt={`${name} – photo ${idx + 1}`}
          loading="lazy"
          style={{
            position: "absolute", inset: 0, width: "100%", height: "100%",
            objectFit: "cover",
            filter: available ? "none" : "grayscale(100%) brightness(0.7)",
            transition: "transform 0.4s ease",
          }}
          onMouseEnter={(e) => (e.target.style.transform = "scale(1.04)")}
          onMouseLeave={(e) => (e.target.style.transform = "scale(1)")}
        />
      ) : (
        <div style={{
          position: "absolute", inset: 0, background: "#2a2a2a",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <span style={{ color: "#666", fontSize: 13, fontFamily: "serif" }}>No photo yet</span>
        </div>
      )}

      {/* Sold banner */}
      {!available && (
        <div style={{
          position: "absolute", inset: 0, display: "flex",
          alignItems: "center", justifyContent: "center",
          background: "rgba(0,0,0,0.35)",
        }}>
          <span style={{
            background: "#c0392b", color: "#fff",
            fontWeight: 700, fontSize: 13, letterSpacing: "0.15em",
            padding: "6px 20px", textTransform: "uppercase",
            fontFamily: "'DM Sans', sans-serif",
          }}>SOLD</span>
        </div>
      )}

      {/* Dot navigation */}
      {images.length > 1 && (
        <div style={{
          position: "absolute", bottom: 10, left: "50%",
          transform: "translateX(-50%)", display: "flex", gap: 5,
        }}>
          {images.map((_, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              aria-label={`Photo ${i + 1}`}
              style={{
                width: i === idx ? 18 : 6, height: 6, borderRadius: 3,
                background: i === idx ? "#fff" : "rgba(255,255,255,0.5)",
                border: "none", cursor: "pointer", padding: 0,
                transition: "all 0.2s",
              }}
            />
          ))}
        </div>
      )}

      {/* Tap zones */}
      {images.length > 1 && (
        <>
          <button
            onClick={() => setIdx((i) => (i - 1 + images.length) % images.length)}
            aria-label="Previous photo"
            style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "30%", background: "none", border: "none", cursor: "pointer" }}
          />
          <button
            onClick={() => setIdx((i) => (i + 1) % images.length)}
            aria-label="Next photo"
            style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: "30%", background: "none", border: "none", cursor: "pointer" }}
          />
        </>
      )}
    </div>
  );
}
