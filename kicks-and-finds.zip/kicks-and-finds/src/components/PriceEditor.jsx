import { useState, useEffect, useRef } from "react";
import { Edit2, Check, X } from "lucide-react";
import { formatPrice } from "../utils/helpers";

export default function PriceEditor({ price, onSave, adminMode }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(price);
  const inputRef = useRef(null);

  useEffect(() => {
    if (editing && inputRef.current) inputRef.current.focus();
  }, [editing]);

  if (!adminMode) {
    return (
      <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, fontWeight: 700, color: "#1a1a1a" }}>
        {formatPrice(price)}
      </span>
    );
  }

  return editing ? (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <span style={{ fontFamily: "monospace", fontSize: 14, color: "#888" }}>KES</span>
      <input
        ref={inputRef}
        type="number"
        value={val}
        onChange={(e) => setVal(Number(e.target.value))}
        onKeyDown={(e) => {
          if (e.key === "Enter") { onSave(val); setEditing(false); }
          if (e.key === "Escape") { setVal(price); setEditing(false); }
        }}
        style={{
          width: 90, padding: "4px 8px",
          border: "2px solid #c8a96e", borderRadius: 6,
          fontFamily: "'DM Sans', sans-serif", fontSize: 16, fontWeight: 700, outline: "none",
        }}
      />
      <button
        onClick={() => { onSave(val); setEditing(false); }}
        style={{ background: "#2d6a4f", color: "#fff", border: "none", borderRadius: 5, padding: "5px 8px", cursor: "pointer" }}
      >
        <Check size={13} />
      </button>
      <button
        onClick={() => { setVal(price); setEditing(false); }}
        style={{ background: "#c0392b", color: "#fff", border: "none", borderRadius: 5, padding: "5px 8px", cursor: "pointer" }}
      >
        <X size={13} />
      </button>
    </div>
  ) : (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, fontWeight: 700, color: "#1a1a1a" }}>
        {formatPrice(price)}
      </span>
      <button
        onClick={() => setEditing(true)}
        title="Edit price"
        style={{ background: "none", border: "1px dashed #c8a96e", borderRadius: 5, padding: "3px 7px", cursor: "pointer", color: "#c8a96e" }}
      >
        <Edit2 size={12} />
      </button>
    </div>
  );
}
