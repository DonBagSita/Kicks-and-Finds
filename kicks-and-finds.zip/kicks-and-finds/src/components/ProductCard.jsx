import { useState } from "react";
import { Heart, MessageCircle, Clock, CheckCircle, XCircle, ToggleLeft, ToggleRight } from "lucide-react";
import ProductImage from "./ProductImage";
import PriceEditor from "./PriceEditor";
import { timeAgo, buildWhatsAppLink } from "../utils/helpers";

export default function ProductCard({ product, onUpdatePrice, onToggleAvailable, adminMode }) {
  const [liked, setLiked] = useState(false);

  const waLink = buildWhatsAppLink(product.whatsapp, product.name, product.price, "enquire");
  const lipaLink = buildWhatsAppLink(product.whatsapp, product.name, product.price, "lipa");

  return (
    <div
      style={{
        background: "#fff",
        borderRadius: 16,
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(0,0,0,0.07)",
        display: "flex",
        flexDirection: "column",
        transition: "box-shadow 0.2s, transform 0.2s",
        position: "relative",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = "0 8px 32px rgba(0,0,0,0.14)";
        e.currentTarget.style.transform = "translateY(-3px)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = "0 2px 12px rgba(0,0,0,0.07)";
        e.currentTarget.style.transform = "translateY(0)";
      }}
    >
      {/* ── Image ── */}
      <div style={{ position: "relative" }}>
        <ProductImage images={product.images} available={product.available} name={product.name} />

        {/* Like */}
        <button
          onClick={() => setLiked((l) => !l)}
          aria-label="Like"
          style={{
            position: "absolute", top: 12, right: 12,
            background: "rgba(255,255,255,0.9)", backdropFilter: "blur(4px)",
            border: "none", borderRadius: "50%", width: 36, height: 36,
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
            transition: "transform 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.15)")}
          onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
        >
          <Heart size={16} fill={liked ? "#e74c3c" : "none"} color={liked ? "#e74c3c" : "#555"} />
        </button>

        {/* Condition badge */}
        <div style={{
          position: "absolute", top: 12, left: 12,
          background: "rgba(255,255,255,0.92)", backdropFilter: "blur(4px)",
          borderRadius: 20, padding: "3px 10px",
          fontSize: 11, fontFamily: "'DM Sans', sans-serif", fontWeight: 600,
          color: "#333", letterSpacing: "0.04em",
        }}>
          {product.condition}
        </div>
      </div>

      {/* ── Info ── */}
      <div style={{ padding: "16px 18px 20px", flex: 1, display: "flex", flexDirection: "column", gap: 10 }}>
        {/* Brand + time */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 11, fontFamily: "'DM Sans', sans-serif", fontWeight: 700, color: "#c8a96e", textTransform: "uppercase", letterSpacing: "0.12em" }}>
            {product.brand}
          </span>
          <span style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#aaa", fontFamily: "'DM Sans', sans-serif" }}>
            <Clock size={11} /> {timeAgo(product.postedAt)}
          </span>
        </div>

        {/* Name */}
        <h2 style={{ margin: 0, fontSize: 15, fontFamily: "'Playfair Display', serif", fontWeight: 600, color: "#1a1a1a", lineHeight: 1.35 }}>
          {product.name}
        </h2>

        {/* Description */}
        <p style={{ margin: 0, fontSize: 12.5, fontFamily: "'DM Sans', sans-serif", color: "#777", lineHeight: 1.6 }}>
          {product.description}
        </p>

        {/* Availability row */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
            {product.available
              ? <><CheckCircle size={13} color="#2d6a4f" /><span style={{ fontSize: 12, color: "#2d6a4f", fontFamily: "'DM Sans', sans-serif", fontWeight: 600 }}>Available</span></>
              : <><XCircle size={13} color="#c0392b" /><span style={{ fontSize: 12, color: "#c0392b", fontFamily: "'DM Sans', sans-serif", fontWeight: 600 }}>Sold</span></>}
          </div>

          {/* Admin toggle */}
          {adminMode && (
            <button
              onClick={() => onToggleAvailable(product.id, !product.available)}
              style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#888" }}
            >
              {product.available
                ? <><ToggleRight size={18} color="#2d6a4f" /> Mark sold</>
                : <><ToggleLeft size={18} color="#888" /> Mark available</>}
            </button>
          )}
        </div>

        {/* Price */}
        <div style={{ marginTop: 2 }}>
          <PriceEditor price={product.price} onSave={(p) => onUpdatePrice(product.id, p)} adminMode={adminMode} />
        </div>

        {/* CTA buttons */}
        {product.available && (
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                flex: 2, display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
                background: "#25D366", color: "#fff",
                borderRadius: 10, padding: "11px 0",
                fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: 13,
                textDecoration: "none", transition: "opacity 0.15s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.85")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              <MessageCircle size={15} /> Enquire
            </a>
            <a
              href={lipaLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                flex: 2, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                background: "#1a1a1a", color: "#c8a96e",
                borderRadius: 10, padding: "11px 0",
                fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: 12,
                textDecoration: "none", border: "1.5px solid #2d2d2d", transition: "background 0.15s",
                letterSpacing: "0.03em",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#2d2d2d")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "#1a1a1a")}
            >
              💳 Lipa Pole Pole
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
